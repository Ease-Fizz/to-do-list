const typingText = document.querySelector('.typing-text p');
const inpField = document.querySelector('.wrapper .input-field');
const tryAgain = document.querySelector('.content button');
const timeTag = document.querySelector('.time span b');
const mistakeTag = document.querySelector('.mistake span');
const wmpTag = document.querySelector('.wpm span');
const cpmTag = document.querySelector('.cpm span');

let timer;
maxTime = 60;
timeLeft = maxTime;
charIndex = mistake = isTyping = 0;

function loadParagraph(){
    const ranIndex = Math.floor(Math.random()*paragraphs.length);
    typingText.innerHTML = '';
    paragraphs[ranIndex].split(" ").forEach( char=>{
        let span = `<span> ${char} </span>`;
        typingText.innerHTML += span;
    });
    typingText.querySelectorAll('span')[0].classList.add("active");
    document.addEventListener('keydown',() => inpField.focus());
    document.addEventListener('click',() => inpField.focus());

}


function initTyping(){
    let characters = typingText.querySelector('span');
    let typedChar = inpField.value.split(" ")[charIndex];
    if(charIndex < characters.length - 1 && timeLeft > 0){
        if(!isTyping){
            timer = setInterval(initTimer, 1000);
            isTyping = true;
        }
        if(typedChar == null){
            if(charIndex > 0 ){
                charIndex --;
                if(characters[charIndex].classList.contains('incorrect')){
                    mistake--;
                }
                    characters[charIndex].classList.remove('correct', 'incorrect')
                }
            }else{
                if(characters[charIndex].innerText == typedChar){
                    characters[charIndex].classList.add('correcct');
                }else{
                    mistake ++;
                    characters[charIndex].classList.add('incorrect');
                }
                charIndex ++ ;
            }
            
        }
    }











